import docsRoute from './docs/docs.route'
import churchRoute from './church/church.route'
import userRoute from './users/user.route'

export { docsRoute, churchRoute, userRoute }

export const swagger = {
  openapi: '3.0.0',
  info: {
    title: 'Task Management',
    version: '1.0.0',
    description: 'API endpoints for user authentication',
  },
}